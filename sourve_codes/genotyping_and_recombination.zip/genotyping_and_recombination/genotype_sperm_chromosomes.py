#!/usr/bin/env python3
"""Reference implementation for single-sperm chromosome genotyping.

This script implements the filtering and 10-kb window haplotype assignment
summarized in the manuscript Methods section. It is intentionally small and
transparent so reviewers can run the supplied demo dataset.
"""
import argparse
import csv
import os
from collections import Counter, defaultdict


def read_tsv(path):
    with open(path, newline='') as fh:
        return list(csv.DictReader(fh, delimiter='\t'))


def write_tsv(path, rows, fields):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=fields, delimiter='\t')
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, '') for k in fields})


def assign_hap(row, hap_cols, base):
    hits = [h for h in hap_cols if row[h].upper() == base.upper()]
    if len(hits) == 1:
        return hits[0]
    if len(hits) > 1:
        return ';'.join(hits)
    return 'unknown'


def main():
    ap = argparse.ArgumentParser(description='Filter SNPs and assign 10-kb window haplotypes for single-sperm genotyping.')
    ap.add_argument('--haplotypes', required=True, help='TSV: chrom,pos,hap1,hap2[,hap3...]')
    ap.add_argument('--snp-genotypes', required=True, help='TSV: sample,chrom,pos,base,depth')
    ap.add_argument('--chrom-sizes', required=True, help='TSV: chrom,length')
    ap.add_argument('--window-size', type=int, default=10000)
    ap.add_argument('--min-window-snps', type=int, default=10)
    ap.add_argument('--min-depth', type=int, default=6)
    ap.add_argument('--max-depth', type=int, default=30)
    ap.add_argument('--min-snp-distance', type=int, default=5)
    ap.add_argument('--outdir', required=True)
    args = ap.parse_args()

    hap_rows = read_tsv(args.haplotypes)
    genotype_rows = read_tsv(args.snp_genotypes)
    chrom_sizes = {r['chrom']: int(r['length']) for r in read_tsv(args.chrom_sizes)}
    hap_cols = [c for c in hap_rows[0].keys() if c.startswith('hap')]

    hap_by_key = {(r['chrom'], int(r['pos'])): r for r in hap_rows}
    geno_by_key = {(r['sample'], r['chrom'], int(r['pos'])): r for r in genotype_rows}
    samples = sorted({r['sample'] for r in genotype_rows})

    filtered = []
    removed = []
    for sample in samples:
        # precompute chromosome SNP positions to apply adjacent-distance filtering
        positions_by_chrom = defaultdict(list)
        for chrom, pos in [(r['chrom'], int(r['pos'])) for r in hap_rows]:
            positions_by_chrom[chrom].append(pos)
        close_sites = set()
        for chrom, positions in positions_by_chrom.items():
            positions = sorted(positions)
            for i, pos in enumerate(positions):
                if (i > 0 and pos - positions[i-1] < args.min_snp_distance) or (i < len(positions)-1 and positions[i+1] - pos < args.min_snp_distance):
                    close_sites.add((chrom, pos))

        raw_assigned = []
        for hr in hap_rows:
            chrom, pos = hr['chrom'], int(hr['pos'])
            alleles = [hr[h].upper() for h in hap_cols]
            key = (sample, chrom, pos)
            gr = geno_by_key.get(key)
            reason = ''
            if len(set(alleles)) == 1 or 'N' in alleles:
                reason = 'non_informative_or_N'
            elif gr is None or gr.get('base', '').upper() in ('', 'N', '.'):
                reason = 'missing_genotype'
            elif int(float(gr['depth'])) < args.min_depth:
                reason = 'depth_lt_min'
            elif int(float(gr['depth'])) > args.max_depth:
                reason = 'depth_gt_max'
            elif (chrom, pos) in close_sites:
                reason = 'too_close_to_adjacent_snp'
            if reason:
                removed.append({'sample': sample, 'chrom': chrom, 'pos': pos, 'reason': reason})
                continue
            assigned = assign_hap(hr, hap_cols, gr['base'])
            raw_assigned.append({'sample': sample, 'chrom': chrom, 'pos': pos, 'base': gr['base'], 'depth': gr['depth'], 'assigned_hap': assigned})

        # remove isolated conflicts: if adjacent assigned SNPs on both sides agree and current differs
        by_chrom = defaultdict(list)
        for r in raw_assigned:
            by_chrom[r['chrom']].append(r)
        for chrom, rows in by_chrom.items():
            rows = sorted(rows, key=lambda x: int(x['pos']))
            for i, r in enumerate(rows):
                if 0 < i < len(rows)-1 and rows[i-1]['assigned_hap'] == rows[i+1]['assigned_hap'] and r['assigned_hap'] != rows[i-1]['assigned_hap']:
                    removed.append({'sample': sample, 'chrom': chrom, 'pos': r['pos'], 'reason': 'isolated_conflict'})
                else:
                    filtered.append(r)

    # window haplotype assignment
    windows = []
    by_sample_chrom_win = defaultdict(list)
    for r in filtered:
        win_start = (int(r['pos']) - 1) // args.window_size * args.window_size + 1
        win_end = min(win_start + args.window_size - 1, chrom_sizes.get(r['chrom'], win_start + args.window_size - 1))
        by_sample_chrom_win[(r['sample'], r['chrom'], win_start, win_end)].append(r)
    for (sample, chrom, start, end), rows in sorted(by_sample_chrom_win.items()):
        n = len(rows)
        counts = Counter(r['assigned_hap'] for r in rows if ';' not in r['assigned_hap'] and r['assigned_hap'] != 'unknown')
        if n >= args.min_window_snps and counts:
            hap, count = counts.most_common(1)[0]
            status = 'assigned'
        else:
            hap, count, status = 'NA', 0, 'insufficient_snps'
        windows.append({'sample': sample, 'chrom': chrom, 'window_start': start, 'window_end': end, 'n_snps': n, 'assigned_hap': hap, 'supporting_snps': count, 'status': status})

    chrom_calls = []
    by_sample_chrom = defaultdict(list)
    for w in windows:
        by_sample_chrom[(w['sample'], w['chrom'])].append(w)
    for (sample, chrom), rows in sorted(by_sample_chrom.items()):
        assigned = [r['assigned_hap'] for r in rows if r['status'] == 'assigned']
        counts = Counter(assigned)
        call = ';'.join([f'{k}:{v}' for k, v in counts.most_common()]) if counts else 'NA'
        chrom_calls.append({'sample': sample, 'chrom': chrom, 'assigned_window_count': len(assigned), 'chromosome_haplotype_summary': call})

    write_tsv(os.path.join(args.outdir, 'filtered_snp_haplotypes.tsv'), filtered, ['sample','chrom','pos','base','depth','assigned_hap'])
    write_tsv(os.path.join(args.outdir, 'removed_snps.tsv'), removed, ['sample','chrom','pos','reason'])
    write_tsv(os.path.join(args.outdir, 'window_haplotypes.tsv'), windows, ['sample','chrom','window_start','window_end','n_snps','assigned_hap','supporting_snps','status'])
    write_tsv(os.path.join(args.outdir, 'chromosome_calls.tsv'), chrom_calls, ['sample','chrom','assigned_window_count','chromosome_haplotype_summary'])


if __name__ == '__main__':
    main()
