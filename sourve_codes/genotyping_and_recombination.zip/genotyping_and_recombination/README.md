# Genotyping and recombination analysis

This directory contains the reader-facing reference implementation for the Methods sections **Sperm chromosome genotyping** and **Recombination**.

Files:

- `genotype_sperm_chromosomes.py`: filters informative SNPs and assigns haplotypes in 10-kb windows for single-sperm chromosome genotyping.
- `call_recombination.py`: calls haplotype-switch recombination events and groups adjacent inconsistent SNPs as candidate gene-conversion regions.

These scripts are compact, transparent implementations intended for peer-review testing with the supplied demo data. The larger HWM analysis code collection under `source_code/HWM.backScipt/` contains the broader production-oriented upstream workflow for read mapping, depth analysis, SNP calling, phasing and related downstream summaries.

Demo usage from the package root:

```bash
python source_code/genotyping_and_recombination/genotype_sperm_chromosomes.py \
  --haplotypes demo_data/genotyping_and_recombination/chromosome_haplotypes.tsv \
  --snp-genotypes demo_data/genotyping_and_recombination/demo_sperm_snps.tsv \
  --chrom-sizes demo_data/genotyping_and_recombination/chrom_sizes.tsv \
  --window-size 10000 \
  --min-window-snps 10 \
  --min-depth 6 \
  --max-depth 30 \
  --min-snp-distance 5 \
  --outdir demo_output/genotyping_and_recombination/genotyping

python source_code/genotyping_and_recombination/call_recombination.py \
  --window-genotypes demo_output/genotyping_and_recombination/genotyping/window_haplotypes.tsv \
  --snp-haplotypes demo_output/genotyping_and_recombination/genotyping/filtered_snp_haplotypes.tsv \
  --flank-snps 20 \
  --outdir demo_output/genotyping_and_recombination/recombination
```
