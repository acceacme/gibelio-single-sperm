#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 03日 星期六 11:20:43 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-03;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"$ARGV[1]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my %hash=();

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		my $keys=$inf[0]."_$inf[1]";
		$hash{$keys}=1;
	}
close IA;

	while(<IB>)
	{
		chomp ;
		next if  ($_=~s/##/##/);
		my @inf=split ;
		my $keys=$inf[0]."_$inf[1]";
		if (exists $hash{$keys} )
		{
			print $_,"\n";
		}
	}
#close OA ;
	close IB;

######################swimming in the sky and flying in the sea ###########################
