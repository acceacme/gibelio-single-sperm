#!/bin/bash
#PBS    -N   GTK.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/05.GATK/02.S16Rzi
#Version1.0	jfgui@genomics.org.cn	2022-07-20
java	-Xmx16g	-Djava.io.tmpdir=./	-jar	/newlustre/home/jfgui/hewm2008/01.Soft/gatk-4.2.2.0/gatk-package-4.2.2.0-local.jar	HaplotypeCaller	-R	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-ploidy	3	-I	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/05.GATK/02.S16Rzi/Bam.list	-native-pair-hmm-threads	13	-O	02.ALL.raw.vcf	-L /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/05.GATK/02.S16Rzi/AA.bed 
echo End Time : 
date
