#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 07月 29日 星期五 16:05:21 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-07-29;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################
use FileHandle;   # open multi_file
    my $filelist= shift  ;

    my @file=();  my %fh=();
    my $file_cout=0 ;

    open (Flist , "<$filelist") || die "$!" ;
    $_=<Flist>; chomp ; my @head=split ;

	
    foreach my $file_cout (1..$#head)
	{
        $file[$file_cout]=$_ ;
        $fh{$file_cout}=FileHandle->new(">$head[$file_cout].list");
    }

    while(<Flist>)
    {
        chomp ;
        my @inf=split ;
		my @ID=split /\./,$inf[0];

		foreach my $i (1..$#head)
#        for(my $i=1 ;  $i<=$#head;  $i++)
        {
			if ($inf[$i]==1)
			{
            my $a=$fh{$i} ;
			my $bb="/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.$ID[-1]/02.BWA/$ID[-1].dup.sort.bam";
				print $a  "$bb\n";
			}
        }
    }

    close Flist ;
	 foreach my $file_cout (1..$#head)
	 {
		 my $a=$fh{$file_cout};
		 $a->close;
	 }
