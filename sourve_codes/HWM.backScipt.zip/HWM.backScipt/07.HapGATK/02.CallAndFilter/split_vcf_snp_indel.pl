#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Tue Mar 17 15:46:00 CST 2015
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2015-03-17;\nUsage: $0 <In.vcf><OutSNP.vcf><OutInDel.vcf>\n" unless (@ARGV ==3);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

open (OA,">$ARGV[1]") || die "output file can't open $!" ;
open (OB,">$ARGV[2]") || die "output file can't open $!" ;

################ Do what you want to do #######################

while(<IA>)
{
	chomp ;
	if ($_=~/^#/)
	{
		print OA $_,"\n";
		print OB $_,"\n";
	}
	else
	{
		my @inf=split ;
		next if  ($_=~s/;AF=1.00;/;AF=1.00;/);
#		next if ($inf[5] <250);
#T       TA
		my @BBB=split(/\,/,$inf[4]);
		my $ccc=1;
		for (my $UU=0; $UU<=$#BBB; $UU++)
		{
			if (length($BBB[$UU])>$ccc)
			{
				$ccc=length($BBB[$UU]);
			}
		}

		if (length($inf[3])==1  &&  $ccc==1 && (!($inf[4]=~s/\*/\*/)) )
		{
			print OA $_,"\n";
		}
		else
		{
			print OB $_,"\n";
		}
	}
}


close IA;
close OA ;
close OB ;

######################swimming in the sky and flying in the sea ###########################
