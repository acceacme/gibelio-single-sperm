#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 04日 星期四 14:14:50 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-04;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

    my $list= shift ;
    my $outDir =`pwd` ;  chomp  $outDir ;
    my $oshbin="perl   /ifs1/ST_POP/USER/heweiming/bin/command/osh.pl" ;
    my $run_bin="";

    open (FL , "<$list") || die "$!" ;
    while (<FL>)
    {
        chomp ;
        my @inf=split ;
        my $id=(split(/\./,$inf[-1]))[0];
		my $Min=int(3.63*$inf[-2])+1;
		my $Max=int(34.10*$inf[-2])+1;
		my $EEE=int($inf[-2]/3)+1;
my $BBB=<<EEE;
#!/bin/bash
#PBS    -N   F$id.sh
#PBS    -l      nodes=1:ppn=10 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/06.HapGATK/04.Filter
Ref=/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa
GATK=/newlustre/home/jfgui/hewm2008/01.Soft/gatk-4.2.2.0/gatk-package-4.2.2.0-local.jar
java -Xmx8g -Djava.io.tmpdir=./ -jar \$GATK VariantFiltration -V ../03.GATK/$id.vcf      -R \$Ref --filter "QUAL <100.0" --filter-name LowQ --filter "DP < $Min  " --filter-name LowD --filter " DP> $Max " --filter-name HigD --filter " MQ<55.0 || QD<5.0  || FS>20.0 || BaseQRankSum<-4.0 || ReadPosRankSum<-3.0 || MQRankSum <-10.0 " --filter-name SedT --filter "SOR > 3.0 " --filter-name LowSOR    --filter "AN < $EEE  " --filter-name LowMiss    -O $id.vcf
grep  -v "##"  $id.vcf |egrep  "#|PASS"  > $id.F1.vcf
perl  Noname_1.pl  $id.F1.vcf  >$id.F2.vcf
/newlustre/home/jfgui/hewm2008/01.Soft/iTools_Code/iTools	Vartools  VCFFilter   -InPut $id.F2.vcf   -OutPut  $id.F3.vcf    -Miss  0.5
gzip -d $id.F3.vcf.gz 
rm  $id.F2.vcf
perl  SplitBB.pl   $id.F3.vcf   $id.F4.SNP.vcf   $id.F4.InDel.vcf
java  -Xmx5940m -jar    /newlustre/home/jfgui/hewm2008/01.Soft/beagle-5.4/beagle.22Jul22.46e.jar   gt=$id.F4.SNP.vcf  out=$id.F4.SNP.phase.vcf

echo End Time : 
date

EEE
		
    open (OUT , ">step1.$id.sh") || die "$!" ;
	print OUT $BBB;
	close OUT;
#        system ("$oshbin   01 01 I$id  $run_bin  " );

    }
    close FL ;


