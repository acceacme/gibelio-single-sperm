#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 05月 05日 星期四 14:43:55 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-05-05;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
#  GT:AD:DP:GQ:PL  1:0,2:2:74:74,0
$_=<IA>; print $_;
	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		foreach my $k (9..$#inf)
		{
			my @ccc=split /\:/,$inf[$k];
			next if  ($ccc[0] eq ".");
			if  ($ccc[2] <6)
			{
				$ccc[0]=".";
			}
			$inf[$k]=join(":",@ccc);

		}
		$_=join("\t",@inf);
		print $_,"\n";
#chr030  18349919        .       TTATATATATATATATATA     T,TTATATATATATATATA     213.33  PASS    AC=1,6;AF=0.0
		#
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
