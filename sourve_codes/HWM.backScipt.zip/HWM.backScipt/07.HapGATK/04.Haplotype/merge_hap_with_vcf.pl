#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Mon Aug  1 15:21:36 HKT 2022
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2022-08-01;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################
open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"gzip -cd $ARGV[1] | ") || die "input file can't open $!";
#open (OA,">$ARGV[1]") || die "output file can't open $!" ;
################ Do what you want to do #######################
my @qqq=split /\//,$ARGV[1];
my @www=split /\./,$qqq[-1];
my $chr=$www[0];
my %hash1=();
my %hash2=();
my %hash3=();
while(<IA>)
{
	chomp ;
	my @inf=split ;
	next  if  ($chr ne $inf[0]);
	if ($inf[1] eq "Hap1")
	{
		foreach my $k (2..$#inf)
		{
			$hash1{$inf[$k]}=1;
		}
	}
	if ($inf[1] eq "Hap2")
	{
		foreach my $k (2..$#inf)
		{
			$hash2{$inf[$k]}=1;
		}
	}
	if ($inf[1] eq "Hap3")
	{
		foreach my $k (2..$#inf)
		{
			$hash3{$inf[$k]}=1;
		}
	}



}
close IA;



$_=<IB>; chomp ;
my @head=split ;
my %TTT=();
foreach my $ttt (0..$#head)
{
	$TTT{$head[$ttt]}=$ttt;
}
print $head[0],"\t$head[1]\tHap1\tHap2\tHap3";
my  @Arr1=sort  keys %hash1;
my  @Arr2=sort  keys %hash2;
my  @Arr3=sort  keys %hash3;

print "\t$Arr1[0]";
$Arr1[0]=$TTT{$Arr1[0]};
foreach my $k  (1..$#Arr1)
{
	print " $Arr1[$k]";
	$Arr1[$k]=$TTT{$Arr1[$k]};
}

print "\t$Arr2[0]";
$Arr2[0]=$TTT{$Arr2[0]};
foreach my $k  (1..$#Arr2)
{
	print " $Arr2[$k]";
	$Arr2[$k]=$TTT{$Arr2[$k]};
}

print "\t$Arr3[0]";
$Arr3[0]=$TTT{$Arr3[0]};
foreach my $k  (1..$#Arr3)
{
	print " $Arr3[$k]";
	$Arr3[$k]=$TTT{$Arr3[$k]};
}
print "\n";

while(<IB>)
{
	chomp ;
	my @inf=split ;



	my %tmphap1=();
	foreach my $k  (0..$#Arr1)
	{
		next if  ($inf[$Arr1[$k]] eq '-');
		$tmphap1{$inf[$Arr1[$k]]}++;
	}
	my  @key_sort1 = sort { $tmphap1{$b} <=> $tmphap1{$a} } keys %tmphap1;
	my  $Hap1=$key_sort1[0];  $Hap1||="-";

	my %tmphap2=();
	foreach my $k  (0..$#Arr2)
	{
		next if  ($inf[$Arr2[$k]] eq '-');
		$tmphap2{$inf[$Arr2[$k]]}++;
	}
	my  @key_sort2 = sort { $tmphap2{$b} <=> $tmphap2{$a} } keys %tmphap2;
	my $Hap2=$key_sort2[0];  $Hap2||="-";

	my %tmphap3=();
	foreach my $k  (0..$#Arr3)
	{
		next if  ($inf[$Arr3[$k]] eq '-');
		$tmphap3{$inf[$Arr3[$k]]}++;
	}

	my  @key_sort3 = sort { $tmphap3{$b} <=> $tmphap3{$a} } keys %tmphap3;
	my $Hap3=$key_sort3[0];  $Hap3||="-";

	next if  (( $Hap1 eq $Hap2 )  &&  ( $Hap1 eq $Hap3 ) );
	next if  (( $Hap1 eq $Hap2 )  &&  ( '-' eq $Hap3 ) );
	next if  (( $Hap1 eq $Hap3 )  &&  ( '-' eq $Hap2 ) );
	next if  (( $Hap2 eq $Hap3 )  &&  ( '-' eq $Hap1 ) );
	next if  (( '-' eq $Hap3 )  &&  ( '-' eq $Hap2 ) );
	next if  (( '-' eq $Hap1 )  &&  ( '-' eq $Hap2 ) );
	next if  (( '-' eq $Hap1 )  &&  ( '-' eq $Hap3 ) );

	print $inf[0],"\t$inf[1]\t$Hap1\t$Hap2\t$Hap3";

	print "\t$inf[$Arr1[0]]";
	foreach my $k  (1..$#Arr1)
	{
		print " $inf[$Arr1[$k]]";
	}

	print "\t$inf[$Arr2[0]]";
	foreach my $k  (1..$#Arr2)
	{
		print " $inf[$Arr2[$k]]";
	}

	print "\t$inf[$Arr3[0]]";
	foreach my $k  (1..$#Arr3)
	{
		print " $inf[$Arr3[$k]]";
	}
	print "\n";


}
close IA;


#close OA ;

######################swimming in the sky and flying in the sea ############
