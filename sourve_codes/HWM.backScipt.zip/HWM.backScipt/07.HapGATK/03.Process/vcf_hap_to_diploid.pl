#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Mon Aug  1 14:38:18 HKT 2022
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2022-08-01;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

#open (IA,"gzip -cd $ARGV[0] |  ") || die "input file can't open $!";
open (IA," $ARGV[0]   ") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
#<IA>;<IA>;<IA>;<IA>;
#<IA>;<IA>;<IA>;<IA>;
$_=<IA>; print $_;

while(<IA>)
{
	chomp ;
	my @inf=split ;
	$inf[8]="GT";
	$inf[7]=".";
	foreach my $k (9..$#inf)
	{
		my @BBB=split //,$inf[$k];
		$inf[$k]="$BBB[0]/$BBB[0]";
	}
	$_=join("\t",@inf);
	print $_,"\n";
}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ##############
