#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 09日 星期二 15:06:22 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";


################ Do what you want to do #######################


	while(<IA>) 
	{ 
		chomp ; my @infA=split ; 
		$_=<IA> ;chomp ; my @infB=split ;
		$_=<IA> ;chomp ; my @infC=split ;
		my $Num=$#infA+$#infB+$#infC-3;
		my $ctt=0.58;
		if ($infA[0] eq "chr2A") {$ctt=0.75;}
		if ($infA[0] eq "chr19B") {$ctt=0.75;}
		open (OA,">$infA[0].cofi") || die "output file can't open $!" ;
		print OA "SetParaFor = global\nValueX =$Num\nColorsConf =/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/06.HapGATK/07.FinalHap1/06.cofi/col.file\nChrArrayDirection = horizontal\nCanvasHeightRitao=0.8\nCanvasWidthRitao=$ctt\n";
		my $count=1;
		foreach my $aaa (2..$#infA)
		{
			my $sample=$infA[$aaa];
			print OA "File$count=$infA[0]/$sample\nSetParaFor=Level$count\nShowColumn = File$count:4\nLevelName = \"$sample\"\nNameRatioFontSize=0.8\nNoShowGradien=1\n";
			$count++;
		}
		print   OA "ValueSpacingRatio=0.2\nSetParaFor=Level1\n";

		foreach my $aaa (2..$#infB)
		{
			my $sample=$infB[$aaa];
			print OA "File$count=$infA[0]/$sample\nSetParaFor=Level$count\nShowColumn = File$count:4\nLevelName = \"$sample\"\nNameRatioFontSize=0.8\nNoShowGradien=1\n";
			$count++;
		}
		print   OA "ValueSpacingRatio=0.2\n";

		foreach my $aaa (2..$#infC)
		{
			my $sample=$infC[$aaa];
			print OA "File$count=$infA[0]/$sample\nSetParaFor=Level$count\nShowColumn = File$count:4\nLevelName = \"$sample\"\nNameRatioFontSize=0.8\nNoShowGradien=1\n";
			$count++;
		}


		close OA;

		system (" /newlustre/home/jfgui/hewm2008/01.Soft/RectChr-1.34/bin/RectChr   -InConfi  $infA[0].cofi   -OutPut   $infA[0].svg  ");
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################

##################################### 全局参数 #######################################################

