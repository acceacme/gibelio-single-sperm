#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Mon Aug  1 16:09:24 HKT 2022
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2022-08-01;\nUsage: $0 <InPut><bin><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"gzip -cd $ARGV[0] | ") || die "input file can't open $!";
my $bin=$ARGV[1];
$_=<IA>; chomp ;
my @head=split /\t/;
#chr1A   28259   C       T       T       C C - - C C - C C C     T - T - T T T - -       T - - T
my @HeadAA=split /\s+/,$head[5];
my @HeadBB=split /\s+/,$head[6];
my @HeadCC=split /\s+/,$head[7];

my %CCCC=();
foreach my $k (@HeadAA)
{
	$CCCC{$k}=$head[2];
}
foreach my $k (@HeadBB)
{
	$CCCC{$k}=$head[3];
}

foreach my $k (@HeadCC)
{
	$CCCC{$k}=$head[4];
}


#
################ Do what you want to do #######################
my %hash1=();
my %hash2=();
my %hash3=();
my $max=0;
my $chr="";

while(<IA>)
{
	chomp ;
	my @inf=split /\t/;
	if ($max<$inf[1])
	{
		$max=$inf[1];
	}

	next  if ( ($inf[2] eq $inf[3])  &&  ($inf[2] eq $inf[4]) );
	next  if ( ($inf[2] eq $inf[3])  &&  ('-' eq $inf[4]) );
	next  if ( ($inf[2] eq $inf[4])  &&  ('-' eq $inf[3]) );

	$chr=$inf[0];
	my $key=int($inf[1]/$bin);

	my @AAA=split /\s+/,$inf[5];
	my @BBB=split /\s+/,$inf[6];
	my @CCC=split /\s+/,$inf[7];
	foreach my $ccc (0..$#AAA)
	{
		my $this=$AAA[$ccc];
		next if ($this  eq "-");
		next if ($this  eq "N");
		if  ($inf[2] eq  $this)
		{
			$hash1{$key}{$HeadAA[$ccc]}++;
		}
		elsif  ($inf[3] eq  $this)
		{
			$hash2{$key}{$HeadAA[$ccc]}++;
		}
		elsif  ($inf[4] eq  $this)
		{
			$hash3{$key}{$HeadAA[$ccc]}++;
		}
	}

	foreach my $ccc (0..$#BBB)
	{
		my $this=$BBB[$ccc];
		next if ($this  eq "-");
		next if ($this  eq "N");
		if  ($inf[3] eq  $this)
		{
			$hash2{$key}{$HeadBB[$ccc]}++;
		}
		elsif  ($inf[2] eq  $this)
		{
			$hash1{$key}{$HeadBB[$ccc]}++;
		}
		elsif  ($inf[4] eq  $this)
		{
			$hash3{$key}{$HeadBB[$ccc]}++;
		}
	}

	foreach my $ccc (0..$#CCC)
	{
		my $this=$CCC[$ccc];
		next if ($this  eq "-");
		next if ($this  eq "N");

		if  ($inf[4] eq  $this)
		{
			$hash3{$key}{$HeadCC[$ccc]}++;
		}
		elsif  ($inf[3] eq  $this)
		{
			$hash2{$key}{$HeadCC[$ccc]}++;
		}
		elsif  ($inf[2] eq  $this)
		{
			$hash1{$key}{$HeadCC[$ccc]}++;
		}		
	}




}

close IA;
$max=int($max/$bin);
my $Start=1;
my $End=$bin;
my $FF="NA";

# chr10A  10462   C       T       C       C
foreach my $thisSample (@HeadAA,@HeadBB,@HeadCC)
{
	$Start=1;
	$End=$bin;
	$FF="NA";
	open (OA,">$chr/$thisSample ") || die "output file can't open $!" ;
	foreach my $k (0..$max)
	{
		my $H1=$hash1{$k}{$thisSample}; $H1||=0;
		my $H2=$hash2{$k}{$thisSample}; $H2||=0;
		my $H3=$hash3{$k}{$thisSample}; $H3||=0;
		my $Sum=$H1+$H2+$H3;
		if  ($Sum<10)
		{
			if  ($FF ne "NA")
			{
				print OA "$chr\t$Start\t$End\t$FF\n";

			}
			$Start=$bin*$k;
			$End=$Start+$bin;$Start++;
			$FF="NA";
		}
		else
		{
			my $FinaHH=$head[2];
			if (($H1>=$H2)  && ($H1>=$H3) )
			{
				$FinaHH=$head[2];
			}
			elsif  (($H2>=$H1)  && ($H2>=$H3) )
			{
				$FinaHH=$head[3];
			}
			elsif  (($H3>=$H1)  && ($H3>=$H2) )
			{
				$FinaHH=$head[4];
			}

			my $StartThis=$bin*$k;
			my $EndThis=$StartThis+$bin;
			$StartThis++;

			if  ($FF eq "NA")
			{
				$FF=$FinaHH;
				$Start=$StartThis;
				$End=$EndThis;
			}
			elsif ($FF eq $FinaHH )
			{
				if (($End+1)>=$StartThis)
				{
					$End=$EndThis;
				}
				else
				{
					print OA  "$chr\t$Start\t$End\t$FF\n";
					$Start=$StartThis;
					$End=$EndThis;
				}
			}
			else
			{
				print OA "$chr\t$Start\t$End\t$FF\n";
				$Start=$StartThis;
				$End=$EndThis;
				$FF=$FinaHH;
			}
		}
	}

	print OA "$chr\t$Start\t$End\t$FF\n";
	close OA ;

}

######################swimming in the sky an
