#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Fri Jul 24 03:26:40 Local time zone must be set--see zic manual page 2015
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2015-07-24;\nUsage: $0 <Sample><InPut.vcf><Out>\n" unless (@ARGV==3);

#############Befor  Start  , open the files ####################


open (IEFF,"$ARGV[0] ") || die "input file can't open $!";
open (IB,"$ARGV[1] ") || die "input file can't open $!";
open (OA,">$ARGV[2] ") || die "input file can't open $!";


my %hash=();

while(<IEFF>)
{
	chomp $_ ;
	my @line=split;
	$hash{$line[0]}++;
}
close IEFF;

#$_=<IB>;$_=<IB>;$_=<IB>;$_=<IB>;
#$_=<IB>;$_=<IB>;$_=<IB>;$_=<IB>;
#$_=<IB>;

$_=<IB>; chomp $_;
my @head=split/\s+/,$_;
my $Count=0;
my @Arry=();

foreach my $sample(1..$#head)
{
	if (exists $hash{$head[$sample]})
	{
		$Arry[$Count]=$sample;
		$Count++;
	}
}

print "SubSample Found Number is $Count\n";
$Count--;
################ Do what you want to do #######################
close IB;
open (IC,"$ARGV[1] ") || die "input file can't open $!";
while(<IC>)
{
	chomp ;
	#next if  ($_=~/^#/);
	my @inf=split ;
	print OA "$inf[0]";
	foreach my $k (1..8)
	{
		print OA  "\t$inf[$k]";
	}

	foreach my $k (0..$Count)
	{
		print OA "\t$inf[$Arry[$k]]";
	}
	print OA "\n";
}


close IC;
close OA;

######################swimming in the sky and flying in the sea ###########################

