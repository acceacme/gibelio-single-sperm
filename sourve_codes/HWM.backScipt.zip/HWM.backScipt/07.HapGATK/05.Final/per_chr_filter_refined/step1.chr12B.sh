#!/bin/bash
#PBS    -N   Fchr12B.sh
#PBS    -l      nodes=1:ppn=10 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/06.HapGATK/04.Filter
Ref=/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa
GATK=/newlustre/home/jfgui/hewm2008/01.Soft/gatk-4.2.2.0/gatk-package-4.2.2.0-local.jar
#java -Xmx8g -D#java.io.tmpdir=./ -jar $GATK VariantFiltration -V ./03.GATK/chr12B.vcf      -R $Ref --filter "QUAL <100.0" --filter-name LowQ --filter "DP < 69  " --filter-name LowD --filter " DP> 648 " --filter-name HigD --filter " MQ<55.0 || QD<5.0  || FS>20.0 || BaseQRankSum<-4.0 || ReadPosRankSum<-3.0 || MQRankSum <-10.0 " --filter-name SedT --filter "SOR > 3.0 " --filter-name LowSOR    --filter "AN < 7  " --filter-name LowMiss    -O chr12B.vcf
grep  -v "##"  chr12B.vcf |egrep  "#|PASS"  > chr12B.F1.vcf
perl  Noname_1.pl  chr12B.F1.vcf  >chr12B.F2.vcf
/newlustre/home/jfgui/hewm2008/01.Soft/iTools_Code/iTools	Vartools  VCFFilter   -InPut chr12B.F2.vcf   -OutPut  chr12B.F3.vcf    -Miss  0.5
gzip -d chr12B.F3.vcf.gz 
rm  chr12B.F2.vcf
perl  SplitBB.pl   chr12B.F3.vcf   chr12B.F4.SNP.vcf   chr12B.F4.InDel.vcf
#java  -Xmx5940m -jar    /newlustre/home/jfgui/hewm2008/01.Soft/beagle-5.4/beagle.22Jul22.46e.jar   gt=chr12B.F4.SNP.vcf  out=chr12B.F4.SNP.phase.vcf

echo End Time : 
date

