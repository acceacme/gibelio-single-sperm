#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Mon Aug  1 16:09:24 HKT 2022
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2022-08-01;\nUsage: $0 <InPut><bin><Out>\n" unless (@ARGV ==3);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
my $bin=$ARGV[1];
open (OA,">$ARGV[2]") || die "output file can't open $!" ;
$_=<IA>; chomp ;
my @head=split ;
#
################ Do what you want to do #######################
my %hash1=();
my %hash2=();
my %hash3=();
my $max=0;
my $chr="";

while(<IA>)
{
	chomp ;
	my @inf=split ;
	if ($max<$inf[1])
	{
		$max=$inf[1];
	}
	$chr=$inf[0];
	next if ($inf[-1]  eq "-");
	next if ($inf[-1]  eq "N");
	my $key=int($inf[1]/$bin);

	if  ($inf[2] eq  $inf[-1])
	{
		$hash1{$key}++;
	}
	elsif  ($inf[3] eq  $inf[-1] )
	{
		$hash2{$key}++;
	}
	elsif  ($inf[4] eq  $inf[-1] )
	{
		$hash3{$key}++;
	}
}

close IA;
$max=int($max/$bin);
my $Start=1;
my $End=$bin;
my $FF="NA";

# chr10A  10462   C       T       C       C

foreach my $k (0..$max)
{
	my $H1=$hash1{$k}; $H1||=0;
	my $H2=$hash2{$k}; $H2||=0;
	my $H3=$hash3{$k}; $H3||=0;
	my $Sum=$H1+$H2+$H3;
	if  ($Sum<10)
	{
		if  ($FF ne "NA")
		{
			print OA "$chr\t$Start\t$End\t$FF\n";

		}
		$Start=$bin*$k;
		$End=$Start+$bin;$Start++;
		$FF="NA";

	}
	else
	{
		my $FinaHH=$head[2];
		if (($H1>=$H2)  && ($H1>=$H2) )
		{
			$FinaHH=$head[2];
		}
		elsif  (($H2>=$H1)  && ($H2>=$H3) )
		{
			$FinaHH=$head[3];
		}
		elsif  (($H3>=$H1)  && ($H3>=$H2) )
		{
			$FinaHH=$head[4];
		}

		my $StartThis=$bin*$k;
		my $EndThis=$StartThis+$bin;
		$StartThis++;

		if  ($FF eq "NA")
		{
			$FF=$FinaHH;
			$Start=$StartThis;
			$End=$EndThis;
		}
		elsif ($FF eq $FinaHH )
		{
			if (($End+1)>=$StartThis)
			{
				$End=$EndThis;
			}
			else
			{
				print OA  "$chr\t$Start\t$End\t$FF\n";
				$Start=$StartThis;
				$End=$EndThis;
			}
		}
		else
		{
			print OA "$chr\t$Start\t$End\t$FF\n";
			$Start=$StartThis;
			$End=$EndThis;
			$FF=$FinaHH;
		}
	}
}

print OA "$chr\t$Start\t$End\t$FF\n";
close OA ;


######################swimming in the sky an
