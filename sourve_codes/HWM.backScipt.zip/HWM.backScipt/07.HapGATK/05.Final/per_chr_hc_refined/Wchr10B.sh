#!/bin/bash
#PBS    -N   Wchr10B.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/06.HapGATK/07.FinalHap1/08.ttt
#Version1.0	jfgui@genomics.org.cn	2022-08-09
java	-Xmx16g	-Djava.io.tmpdir=./	-jar	/newlustre/home/jfgui/hewm2008/01.Soft/gatk-4.2.2.0/gatk-package-4.2.2.0-local.jar	HaplotypeCaller	-R	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-I	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/06.HapGATK/07.FinalHap1/08.ttt/01.List/chr10B.bam.list	-native-pair-hmm-threads	12	-O	chr10B.vcf	
echo End Time : 
date
