#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 09日 星期二 17:56:30 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"$ARGV[1]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my %hash=();
	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		$hash{$inf[0]}=$inf[2];		
	}
close IA;

	while(<IB>) 
	{ 
		chomp ; 
		my @inf=split ;
		next  if  (! exists $hash{$inf[0]});
		$inf[-1]=$hash{$inf[0]};
		$_=join("\t",@inf);
		print $_,"\n";
	}
close IB;



#close OA ;

######################swimming in the sky and flying in the sea ###########################
