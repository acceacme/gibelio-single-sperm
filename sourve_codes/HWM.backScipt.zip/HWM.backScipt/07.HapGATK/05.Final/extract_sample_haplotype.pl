#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 09日 星期二 14:38:07 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		print $inf[0],"\t$inf[1]\t$inf[2]\t$inf[3]\t$inf[4]\t$inf[$ARGV[1]]\n";
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
