#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 23日 星期二 13:10:32 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-23;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"$ARGV[1]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my $seq="";
<IA>;
$seq=<IA>; chomp $seq;
close IA;
my $bin=250;

	while(<IB>) 
	{ 
		chomp ; 
		my @inf=split ;
#		$inf[1]--;
		my $head=$inf[1]-$bin-1;
		my $AA=substr($seq,$head,$bin);
		my $BB=substr($seq,$inf[1],$bin);
		print ">$inf[0]_$inf[1]\t$_\n$AA\[$inf[2]/$inf[3]\]$BB\n";
		
	}


close IB;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
