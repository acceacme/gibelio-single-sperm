#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 23日 星期二 10:41:27 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-23;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my %hash=();

$_=<IA>; chomp ; my @head=split ;

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		foreach my $k (1..$#inf)
		{
			next if ($inf[$k] !=1);
			$hash{$inf[0]}{$head[$k]}=$inf[$k];
		}
	}
close IA;


    my $filelist= $ARGV[1];
    open (Flist , "<$filelist") || die "$!" ;
    while ($_=<Flist>)
    {
        chomp ;
        my $file=$_ ;
        open (Fi ,"$file") || die "$!" ;
		my @RR=split /\//,$file ;
		# chr10A/S21
        while ($_=<Fi>)
        {
            chomp ;
            my @inf=split ;
			my $aa="$RR[-2]_$inf[-1]";
			if (! exists $hash{$RR[-1]}{$aa})
			{
				   $aa="$RR[-2]_Hap1"; 
				   $aa="$RR[-2]_Hap2" if (!exists $hash{$RR[-1]}{$aa});
				   $aa="$RR[-2]_Hap3" if (!exists $hash{$RR[-1]}{$aa});
				print $RR[-1],"\t$aa\t$_\n";
			}
        }
        close Fi ;
    }

    close Flist ;


#close OA ;

