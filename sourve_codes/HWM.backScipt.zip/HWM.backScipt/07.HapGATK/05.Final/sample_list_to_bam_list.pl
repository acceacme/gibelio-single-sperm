#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 09日 星期二 16:38:05 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		print "/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.$inf[0]/02.BWA/$inf[0].dup.sort.bam\n";
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
