#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 26日 星期一 17:41:10 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-26;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
<IA>;
	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		my $aa=$inf[-2]*100.0/$inf[1];
		print $_,"\t$aa\n";
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
