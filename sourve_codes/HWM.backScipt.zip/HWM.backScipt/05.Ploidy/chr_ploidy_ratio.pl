#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2021年 09月 07日 星期二 09:07:56 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2021-09-07;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################
my $filelist= shift ;
open (Flist , "<$filelist") || die "$!" ;
my %hash=();
my %cccc=();
my %ddd=();
while ($_=<Flist>)
{
	chomp ;
	my $file=$_ ;
	open (Fi ,"$file") || die "$!" ;
	my @EEE=split /\//,$file;
	$cccc{$EEE[-3]}++;
	while ($_=<Fi>)
	{
		chomp ;
		next if  ($_=~s/#/#/);
		my @inf=split ;
		$hash{$EEE[-3]}{$inf[0]}=$inf[-1];
		$ddd{$inf[0]}++;
	}
	close Fi ;
}
close Flist ;

my @Chr=sort  keys   %ddd;
my @sample =sort keys %cccc;
print "#sample";
foreach  my  $B  (@Chr)
{
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	next if  ($B=~s/^HiC_scaf/HiC_scaff/);
	print "\t$B";
}
print "\n";
my %MeanDepth=();
foreach my $A (@sample)
{
	my $SSS=0;
	my $Num=0;
	foreach  my  $B  (@Chr)
	{
		if ($B=~s/^CM/CM/)
		{
			$Num++;
			$SSS+=$hash{$A}{$B};
		}
	}
	$MeanDepth{$A}=$SSS/$Num;
}

my %NNN=();
foreach my $A (@sample)
{
	print "$A";
	my $sum=0;
	foreach  my  $B  (@Chr)
	{
		next if  ($B=~s/scaf_/scaf_/);
		next if  ($B=~s/^K/K/);
		next if  ($B=~s/^HiC_scaf/HiC_scaff/);
		print "\t$hash{$A}{$B}";
		if  ($hash{$A}{$B} <10)
		{
			$sum++;
			$NNN{$B}++;
		}
	}
	print "\t$sum\n";
}

print "#Sum";
foreach  my  $B  (@Chr)
{
	$NNN{$B}||=0;
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	next if  ($B=~s/^HiC_scaf/HiC_scaff/);
	print "\t$NNN{$B}";
	$NNN{$B}=0;
}
print "\n";
print "\n";
print "\n";
print "\n";
print "#sample";
foreach  my  $B  (@Chr)
{
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	next if  ($B=~s/^HiC_scaf/HiC_scaff/);
	print "\t$B";
}
print "\n";


foreach my $A (@sample)
{
	print "$A";
	my $sum=0;
	foreach  my  $B  (@Chr)
	{
		next if  ($B=~s/scaf_/scaf_/);
		next if  ($B=~s/^K/K/);
		next if  ($B=~s/^HiC_scaf/HiC_scaff/);
		my $EEEE=sprintf ("%.3f",$hash{$A}{$B}/$MeanDepth{$A});
		my $ccc=$EEEE;
		if  ($EEEE <0.4)
		{
			$sum++;
			$NNN{$B}++;
			$EEEE=0;
		}
		elsif ($EEEE >=0.4   &&   $EEEE  < 1.6 )
		{
			$EEEE=1;
		}
		elsif ($EEEE >=1.5   &&   $EEEE  < 2.5 )
		{
			$EEEE=2;
		}
		elsif ($EEEE >=2.5   &&   $EEEE  < 3.5 )
		{
			$EEEE=3;
		}
		else
		{
			$EEEE=int($EEEE);
		}
		
		print "\t$ccc:$EEEE";
		if ($B=~s/chr/chr/)
		{
		$sum+=(3-$EEEE);
		$NNN{$B}+=(3-$EEEE);
		}
	}
	print "\t$sum\n";
}

print "#Sum";
foreach  my  $B  (@Chr)
{
	$NNN{$B}||=0;
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	next if  ($B=~s/^HiC_scaf/HiC_scaff/);
	print "\t$NNN{$B}";
	$NNN{$B}=0;
}
print "\n";
print "\n";
print "\n";
print "\n";

print "#sample";
foreach  my  $B  (@Chr)
{
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	next if  ($B=~s/^HiC_scaf/HiC_scaff/);
	print "\t$B";
}
print "\n";



foreach my $A (@sample)
{
	print "$A";
	my $sum=0;
	foreach  my  $B  (@Chr)
	{
		next if  ($B=~s/scaf_/scaf_/);
		next if  ($B=~s/^K/K/);
		next if  ($B=~s/^HiC_scaf/HiC_scaff/);
		my $EEEE=sprintf ("%.3f",$hash{$A}{$B}/$MeanDepth{$A});
		my $ccc=$EEEE;
		if  ($EEEE <0.4)
		{
			$sum++;
			$NNN{$B}++;
			$EEEE=0;
		}
		elsif ($EEEE >=0.4   &&   $EEEE  < 1.5 )
		{
			$EEEE=1;
		}
		elsif ($EEEE >=1.5   &&   $EEEE  < 2.5 )
		{
			$EEEE=2;
		}
		elsif ($EEEE >=2.5   &&   $EEEE  < 3.5 )
		{
			$EEEE=3;
		}
		else
		{
			$EEEE=int($EEEE);
		}
		
		print "\t$EEEE";
		if ($B=~s/chr/chr/)
		{
		$sum+=(3-$EEEE);
		$NNN{$B}+=(3-$EEEE);
		}
	}
	print "\t$sum\n";
}

print "#Sum";

