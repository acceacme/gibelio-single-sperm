#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-07-20;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"gzip -cd $ARGV[0] | ") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
<IA>;
<IA>;
my $chr="";
my %hash=();
my %count=();
my $bin=100000;

	while(<IA>) 
	{ 
		chomp ; 
		if ($_=~s/>//)
		{
			$chr=$_;
		}
		else
		{
			my @inf=split ;
			my $count=0;
			if ($inf[1]!=0){$count++;}
			if ($inf[2]!=0){$count++;}
			if ($inf[3]!=0){$count++;}
			if ($inf[4]!=0){$count++;}
			next if ($count!=2);
			my $sum=$inf[1]+$inf[2]+$inf[3]+$inf[4];
			next if ($sum<10);
			my $Max=$inf[1];
			if  ($Max<$inf[2]) {$Max=$inf[2];}
			if  ($Max<$inf[3]) {$Max=$inf[3];}
			if  ($Max<$inf[4]) {$Max=$inf[4];}
			my $ccc=1-($Max*1.0/$sum);
			next if ($ccc<0.1);
			my $key=int($inf[0]/$bin);
			$hash{$chr}{$key}+=$ccc;
			$count{$chr}{$key}++;
		}
	}
	#608     0       2       0       0
	
close IA;

foreach my $chr (sort keys %hash )
{
	my $ccc=$hash{$chr};
	foreach my $site (sort {$a<=>$b}  keys %$ccc  )
	{
		my $start=$site*$bin+1;
		my $end=$site*$bin+$bin;
		my $aaa=$hash{$chr}{$site}/$count{$chr}{$site};
		print "$chr\t$start\t$end\t$aaa\t$count{$chr}{$site}\n";
	}

}
#close OA ;

######################swimming in the sky and flying in the sea ###########################
