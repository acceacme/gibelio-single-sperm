#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2021年 09月 07日 星期二 09:07:56 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2021-09-07;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################
    my $filelist= shift ;
    open (Flist , "<$filelist") || die "$!" ;
	my %hash=();
	my %cccc=();
	my %ddd=();
	my %DDsu=();
    while ($_=<Flist>)
    {
        chomp ;
        my $file=$_ ;
        open (Fi ,"$file") || die "$!" ;
		my @EEE=split /\//,$file;
		$EEE[-3]=~s/02.//;
		$cccc{$EEE[-3]}++;
        while ($_=<Fi>)
        {
            chomp ;
			next if  ($_=~s/#/#/);
            my @inf=split ;
			$hash{$EEE[-3]}{$inf[0]}=$inf[-2];
			$ddd{$inf[0]}++;
        }
        close Fi ;
    }
    close Flist ;


my %meanDepth=();
$meanDepth{"S01"}=10.6772;
$meanDepth{"S02"}=14.816;
$meanDepth{"S05"}=12.774;
$meanDepth{"S06"}=13.5052;
$meanDepth{"S07"}=12.4772;
$meanDepth{"S08"}=13.0772;
$meanDepth{"S12"}=13.8696;
$meanDepth{"S13"}=12.5944;
$meanDepth{"S14"}=12.998;
$meanDepth{"S15"}=12.2036;
$meanDepth{"S18"}=12.8124;
$meanDepth{"S19"}=12.9868;
$meanDepth{"S20"}=12.6148;
$meanDepth{"S21"}=18.2628;
$meanDepth{"S25"}=14.8136;
$meanDepth{"S26"}=13.8836;
$meanDepth{"S27"}=17.0504;
$meanDepth{"S31"}=12.0828;
$meanDepth{"S33"}=12.8528;
$meanDepth{"S34"}=19.5944;



my @Chr=sort  keys   %ddd;
my @sample =sort keys %cccc;
print "#sample";
foreach  my  $B  (@Chr)
{
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	print "\t$B";
}
print "\n";
my %NNN=();
foreach my $A (@sample)
{
	print "$A";
	my $sum=0;
	foreach  my  $B  (@Chr)
	{
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);

	my $EEEE=sprintf ("%.2f",$hash{$A}{$B}/$meanDepth{$A});

#		print "$EEEE\n";
		print "\t$hash{$A}{$B}";
		if  ($EEEE <0.3)
		{
			$sum++;
			$NNN{$B}++;
			$EEEE=0;
		}
		elsif ($EEEE >=0.3   &&   $EEEE  < 1.5 )
		{
			$EEEE=1;			
		}
		elsif ($EEEE >=1.5   &&   $EEEE  < 2.5 )
		{
			$EEEE=2;			
		}
		elsif ($EEEE >=2.5   &&   $EEEE  < 3.5 )
		{
			$EEEE=3;			
		}
		else
		{
			 $EEEE="EEE";
		}
		



	}
	print "\t$sum\n";
}

print "#Sum";
foreach  my  $B  (@Chr)
{
	$NNN{$B}||=0;
	next if  ($B=~s/scaf_/scaf_/);
	next if  ($B=~s/^K/K/);
	print "\t$NNN{$B}";
}
print "\n";

