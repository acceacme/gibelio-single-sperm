#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 08日 星期一 13:10:01 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-08;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

my %JJJ=();

	my $filelist= $ARGV[1];
    open (IAT, "<$filelist") || die "$!" ;
	$_=<IAT>; chomp ;
	my @head=split ;
	while(<IAT>)
	{
		chomp ;
   	    my @inf=split ;
		$inf[0]=~s/02.//g;
		for (my $k=1; $k<=$#inf; $k++)
		{
			$JJJ{$head[$k]}{$inf[0]}=$inf[$k];
		}
	}
	close IAT;

	
	$filelist= $ARGV[0];
    open (Flist , "<$filelist") || die "$!" ;
	my %AA=();
	my %BB=();
	my %SS=();

    while ($_=<Flist>)
    {
        chomp ;
        my $file=$_ ;
		my @cccc=split /\//,$file;		
		$cccc[-3]=~s/02.//g;
		my @bbb=split /\./,$cccc[-3];
		my $ID=$bbb[0];
		$SS{$ID}=1;
        open (Fi ,"$file") || die "$!" ;
        while ($_=<Fi>)
        {
            chomp ;
			next if (!($_=~s/chr/chr/g));
            my @inf=split ;
			if  ($inf[-1]>900)
			{
				$BB{$inf[0]}{$ID}++;
			}
			else
			{
				$AA{$inf[0]}{$ID}++;
			}
        }
        close Fi ;
    }
    close Flist ;

	my @Sample=sort keys %SS;
	print "#sample";
	my @chr=sort keys  %AA;
	foreach my  $tmpChr( @chr)
	{
		print "\t$tmpChr";
	}
	print "\n";

	foreach  my $ss (@Sample)
	{
#		print "$ss";
		foreach my  $tmpChr( @chr)
		{
			my $ttt=$AA{$tmpChr}{$ss};	$ttt||=0;
			my $ccc=$BB{$tmpChr}{$ss};  $ccc||=0;
			if ($ttt>$ccc)
			{
				#print "\t1:$ttt:$ccc";
				if  ($JJJ{$tmpChr}{$ss}<2)
				{

				}
				else
				{
					print "$ss\t$tmpChr\t1:$ttt:$ccc\n";
				}
			}
			else
			{
				if  ($JJJ{$tmpChr}{$ss}<2)
				{
					print "$ss\t$tmpChr\t2:$ttt:$ccc\n";
				}
#				print "\t2:$ttt:$ccc";
			}
		}
#		print "\n";
	}



