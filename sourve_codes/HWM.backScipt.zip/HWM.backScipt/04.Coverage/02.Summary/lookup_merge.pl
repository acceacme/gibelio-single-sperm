#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 07日 星期日 15:09:54 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-07;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"$ARGV[1]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my %hash=();
	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		$hash{$inf[0]}=$inf[-1];
	}
close IA;

	while(<IB>) 
	{ 
		chomp ; 
		my @inf=split ;
		$inf[-2]=$hash{$inf[0]};
		$_=join("\t",@inf);
		print $_,"\n";
	}
close IA;


#close OA ;

######################swimming in the sky and flying in the sea ###########################
