#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 07日 星期日 15:09:54 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-07;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==2);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
open (IB,"$ARGV[1]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
my %hash=();

my $filelist= $ARGV[0];
open (IAT, "<$filelist") || die "$!" ;
$_=<IAT>; chomp ;
my @head=split ;
while(<IAT>)
{
	chomp ;
	my @inf=split ;
	$inf[0]=~s/02.//g;
	for (my $k=1; $k<=$#inf; $k++)
	{
		$hash{$head[$k]}{$inf[0]}=$inf[$k];
	}
}
close IAT;



my $file=$ARGV[1] ;
my @cccc=split /\//,$file;
$cccc[-3]=~s/02.//g;
my @bbb=split /\./,$cccc[-3];
my $ID=$bbb[0];



while(<IB>) 
{ 
	chomp ; 
	next if (!($_=~s/chr/chr/g));
	my @inf=split ;
	$inf[-2]=$hash{$inf[0]}{$ID};
	$_=join("\t",@inf);
	print $_,"\n";
}
close IA;


#close OA ;

######################swimming in the sky and flying in the sea ###########################
