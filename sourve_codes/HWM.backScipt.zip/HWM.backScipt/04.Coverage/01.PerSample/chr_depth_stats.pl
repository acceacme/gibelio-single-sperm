#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 08月 07日 星期日 14:34:39 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-08-07;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";
my @cccc=split /\//,$ARGV[0];
$cccc[-3]=~s/02.//g;
my @bbb=split /\./,$cccc[-3];
#print  "$cccc[0]";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
# chr10A  1100001 1200000 0.286891739227743       1342

my %Count=();
my %Sum=();

	while(<IA>)
	{
		chomp ;
		next if (!($_=~s/chr/chr/g));
		my @inf=split ;
		$Count{$inf[0]}+=$inf[-1];
		$Sum{$inf[0]}+=$inf[-2]*$inf[-1];
	}
close IA;


foreach my $k (sort keys %Count)
{
	my $aaaa= $Sum{$k}/$Count{$k};
	print "$bbb[0]\t$k\t$Count{$k}\t$aaaa\n";
}
#close OA ;

######################swimming in the sky and flying in the sea ###########################
