#!/bin/bash
#PBS    -N   DD.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/03.Mapping/02.HL02/04.Stat
#Version1.0	jfgui@genomics.org.cn	2022-07-20
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	BasesCount	-i	../02.BWA/HL02.dup.sort.bam	-o	Site.Depth	
echo End Time : 
date
