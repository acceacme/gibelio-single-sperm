#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 21日 星期三 17:21:17 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-21;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;
my %hash=();

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		foreach my  $k ($inf[2]..$inf[3])
		{
			my $key=$inf[1]."_".$k;
			$hash{$key}++;

		}
	}


close IA;
foreach my $k (keys %hash)
{
	next if ($hash{$k}==1);
	print "$k\t$hash{$k}\n";
}
#close OA ;

######################swimming in the sky and flying in the sea ###########################
