#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 09日 星期五 09:09:43 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
   my $list= shift ;
    my $outDir =`pwd` ;  chomp  $outDir ;
    my $oshbin="perl  /newlustre/home/jfgui/hewm2008/01.Soft/command/osh.pl   " ;
    my $run_bin="";

    open (FL , "<$list") || die "$!" ;
    while (<FL>)
    {
        chomp ;
        my @inf=split/\//;
        my $id=(split(/\./,$inf[-1]))[0];
        system ("$oshbin   01 01 I$id  $run_bin  /newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i  $_   -r	/newlustre/home/jfgui/hewm2008/03.Project/02.Caiyujizi20/01.Ref/Ref.fa	-o $id  -q -2 " );

    }
    close FL ;
