#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 09日 星期五 10:28:45 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-09;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################
#my %hash1=();
#my %hash2=();
#my %hash2=();
my $AA=0;
my $BB=0;
my $CC=0;
	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		if ($inf[0]=~s/chr/chr/)
		{
			$AA++;
			$BB+=$inf[-2];
			$CC+=$inf[-1];
		}
		
	}

my $aaaa=$BB/$AA;
my $bbbb=$CC/$AA;
print "\t$aaaa\t$bbbb\n";
close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
