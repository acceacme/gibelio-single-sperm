#!/bin/bash
#PBS    -N   ES45.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/09.Stat_Repeat
#Version1.0	jfgui@genomics.org.cn	2022-09-20
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S45/02.BWA/S45.dup.sort.bam	-r	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-q	-1	-o	W.S45	
echo End Time : 
date
