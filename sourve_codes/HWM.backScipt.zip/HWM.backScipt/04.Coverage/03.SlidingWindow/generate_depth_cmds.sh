ls ../00.bams/*.bam|cut -d"/" -f3|sed 's/.dup.sort.bam//g'|while read id; do echo "../../../../../01.Soft/PanDepth-2.25/pandepth  -i ../00.bams/${id}.dup.sort.bam -o ${id}_w50k -w 50000";done > get_depth.sh

