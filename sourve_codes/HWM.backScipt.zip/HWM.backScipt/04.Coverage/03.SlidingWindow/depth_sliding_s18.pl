#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 03月 23日 星期三 16:55:45 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-03-23;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==3);

#############Befor  Start  , open the files ####################

open (IA,"gzip -cd $ARGV[0]  | ") || die "input file can't open $!";
my $Bin=$ARGV[1];
open (OA,">$ARGV[2]") || die "output file can't open $!" ;

################ Do what you want to do #######################
$_=<IA>; chomp ;
my $chr="";
if ($_=~s/>//)
{
	$chr=$_;
}
my $Start=1;
my $End=$Start+$Bin-1;
my $Flag=1;
my $Sumdepth=0;
my $CountCov=0;
	while(<IA>)
	{
		chomp ;
		if  ($_=~s/>//)
		{
			$chr=$_;
			$Start=1;
			$End=$Start+$Bin;
			$Flag=1;
			$CountCov=0;
			$Sumdepth=0;
			next ;
		}
		my @inf=split ;		
		foreach my $k (0..$#inf)
		{
			if  (($Flag % $Bin)==0)
			{
				my $meanD=sprintf ("%.2f",$Sumdepth/$Bin);
				my $Cov=sprintf ("%.2f",$CountCov*100.0/$Bin);
				print OA "$chr\t$Start\t$End\t$meanD\t$Cov\n";
				$Start=$End;
				$End=$Start+$Bin;
				$Sumdepth=0;
				$Flag=0;
				$CountCov=1;
			}
			else
			{
				$Sumdepth+=$inf[$k];
				if  ($inf[$k]!=0)
				{
					$CountCov++;
				}
			}
			$Flag++;
		}
	}
close IA;

close OA ;

######################swimming in the sky and flying in the sea ###########################
