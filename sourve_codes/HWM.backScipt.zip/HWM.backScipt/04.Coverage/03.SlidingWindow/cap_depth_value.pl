#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 03月 23日 星期三 21:16:42 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-03-23;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split ;
		if  ($inf[-2]>70)
		{
			$inf[-2]=70;
		}
		$_=join("\t",@inf);
		print $_,"\n";
		
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
