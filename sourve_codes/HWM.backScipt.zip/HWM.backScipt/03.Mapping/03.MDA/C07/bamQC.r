
read.table("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.GC-depth",header=T)->r;
pdf("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.GC-depth.pdf");
plot(r[,1],r[,2],col="blue",type="l",ylab="Depth",xlab="GC content(%)")
text(x =37, y =15450884, col="red",labels = " Peak GC% :37",font=2);
dev.off();
read.table("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.InsertSize",header=T)->r;
pdf("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.InsertSize.pdf");
plot(r[,1],r[,2],col="blue",type="l",ylab="Number",xlab="Insert Size",xlim=c(0,0))
text(x =0, y =2370863, col="red",labels = " Peak Insert Size% :0",font=2);
dev.off();
read.table("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.QC")->r;
pdf("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.QC.base.pdf",w=12,h=6);
plot(r[,2],r[,3],col="red",type="l",ylim=c(0,50),xlab="Position along reads",ylab="Percentage (%)")
lines(r[,2],r[,4],col="green",lty=2)
lines(r[,2],r[,5],col="blue",lty=3)
lines(r[,2],r[,6],col="Purple",lty=4)
lines(r[,2],r[,7],col="Cyan",lty=5)
abline(v=max(r[,2])/2,lty=2)
legend("topright",c("A","C","G","T","N"),col=c("red","green","blue","Purple","Cyan"),cex=1,lty=c(1,2,3,4,5),bty="n");
dev.off();
r2 = r[,c(2,8:ncol(r))]
colnames(r2)=c("read",0:(ncol(r2)-2))
library(reshape)
library(ggplot2)
r3 = melt(r2,id="read")
colnames(r3)=c("read","qualities","depth")
r4 = r3
r4$depth[which(r4$depth==0)] = NA
pdf("/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/04.Stat//bamQC.QC.qual.pdf",w=12,h=6);
p <- ggplot(r4,aes(read,qualities,colour=depth))+geom_point(shape=15) + scale_color_gradient(low='green',high='red',na.value='white')
text_set = theme(axis.title = element_text(size=10),axis.text = element_text(size=8),legend.text = element_text(size=8),legend.title = element_text(size=8))
axis_set_x = scale_x_continuous(expand = c(0,0))
theme_set = theme(panel.background = element_rect(fill = "white", colour = "black"))
p = p + theme_set + text_set + axis_set_x
p
dev.off()

