#!/bin/bash
#PBS    -N   Mq.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C07/00.shell
#Version1.0	jfgui@genomics.org.cn	2023-02-05
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i	../02.BWA/C07.dup.sort.bam	-r	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-o	../04.Stat/MQ0Coverage	-q	-2	
echo End Time : 
date
