#!/bin/bash
#PBS    -N   SC10.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/00.shell
#Version1.0	jfgui@genomics.org.cn	2023-02-03
ln	-s	/newlustre/home/jfgui/wy/spermegg/Ca-MDAalone/Ca-10/Ca-10_R1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_1.fq.gz	
ln	-s	/newlustre/home/jfgui/wy/spermegg/Ca-MDAalone/Ca-10/Ca-10_R2.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_2.fq.gz	
/newlustre/home/jfgui/dingmiao/genome/2021-genome/bin/bwa-0.7.17/bwa	mem	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_2.fq.gz	-R	'@RG\\\tID:C10\\\tPL:illumina\\\tPU:C10\\\tLB:C10\\\tSM:C10'	-t	8	|	/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	view	-b	-S	>	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	fixmate	-m	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	sort	-m	8999M	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.srt.bam	-O	BAM	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.sort.bam	
rm	BWA/C10.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	markdup	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.sort.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.dup.sort.bam	
rm	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	index	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.dup.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.dup.sort.bam	-d	-r	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/04.Stat/Coverage	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	visualize	StatQC	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/02.BWA/C10.dup.sort.bam	-k	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/04.Stat/	
/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck	-InFq1	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_1.fq.gz	-InFq2	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/C10_clean_2.fq.gz	-OutStat1	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/clean_1	-OutStat2	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/10.Mapping/02.C10/01.Fqfliter/clean_2	
echo End Time : 
date
