#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 07月 02日 星期六 13:50:22 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-07-02;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split /\//;
		my @bbb=split /\_/,$inf[-1];
		print $bbb[0],"\t$_\n";
		
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
