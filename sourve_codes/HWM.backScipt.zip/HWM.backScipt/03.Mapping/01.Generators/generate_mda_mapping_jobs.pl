#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to
#edit by hewm;   Fri Feb 15 17:27:45 HKT 2019
#Version 1.0    hewm@genomics.org.cn

die  "Version 1.0\t2019-02-15;\nUsage: $0 <sample2Fq.list><Ref.fa><Out>\n" unless (@ARGV ==3 || @ARGV ==2 );

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

my $Ref=$ARGV[1];

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

my $outDir =`pwd` ;  chomp  $outDir ;
my $oshbin="perl /newlustre/home/jfgui/hewm2008/01.Soft/command/osh.pl   " ;
my $samtools="/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools";
my $fqcheck="/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck";
my $bwa="/newlustre/home/jfgui/dingmiao/genome/2021-genome/bin/bwa-0.7.17/bwa ";
my $bamDeal="/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux";
#"/hwfssz4/BC_COM_P3/F18FTSCCKF3995/GOSrhnR/01.Ref/Ref.fa";

my $iTools="/newlustre/home/jfgui/hewm2008/01.Soft/iTools_Code/iTools";
################ Do what you want to do #######################
my %hash1=();
my %hash2=();

while(<IA>)
{
	chomp ;
	my @infAA=split ;
	$_=<IA>; chomp ;
	my @infBB=split ;

	if (!exists $hash1{$infAA[0]} )
	{
		$hash1{$infAA[0]}=$infAA[-1];
		$hash2{$infBB[0]}=$infBB[-1];
	}
	else
	{
		$hash1{$infAA[0]}=$hash1{$infAA[0]}."\t".$infAA[-1];
		$hash2{$infBB[0]}=$hash2{$infBB[0]}."\t".$infBB[-1];
	}
}

close IA;


foreach my $sample (sort  keys %hash1)
{
	my $ThisSample="$outDir/02.$sample";
	my $shell="$outDir/02.$sample/00.shell";
	my $FqFilter="$outDir/02.$sample/01.Fqfliter";
	my $BWA="$outDir/02.$sample/02.BWA";
	my $Mapping="$outDir/02.$sample/03.Mapping";
	my $Stat="$outDir/02.$sample/04.Stat";

	system ("mkdir  -p  $ThisSample  $shell   $FqFilter  $BWA   $Mapping  $Stat  ");
	chdir $shell;
	my $id=$sample ;
#   "@RG\tID:S01\tPL:illumina\tPU:S01\tLB:S01\tSM:S01"
	system ( " $oshbin     01  01   S$sample    ln -s   $hash1{$sample}      $FqFilter/$sample\_clean_1.fq.gz   ^  ln -s   $hash2{$sample}   $FqFilter/$sample\_clean_2.fq.gz  ^    $bwa  mem   $Ref    $FqFilter/$sample\_clean_1.fq.gz    $FqFilter/$sample\_clean_2.fq.gz     -R \\\'\@RG\\\\\\\\\\\\tID:$id\\\\\\\\\\\\tPL:illumina\\\\\\\\\\\\tPU:$id\\\\\\\\\\\\tLB:$id\\\\\\\\\\\\tSM:$id\\\'    -t  8   \\\|   $samtools view  -b      -S      \\\> $BWA/$id.bam  ^     $samtools  fixmate  -m    $BWA/$id.bam  $BWA/$id.srt.bam     ^            $samtools      sort    -m    8999M    $BWA/$id.srt.bam  -O  BAM -o    $BWA/$id.sort.bam ^ rm  BWA/$id.srt.bam   ^   $samtools markdup  $BWA/$id.sort.bam   $BWA/$id.dup.sort.bam  ^   rm   $BWA/$id.sort.bam   ^   $samtools  index  $BWA/$id.dup.sort.bam   ^  $bamDeal    statistics  Coverage   -i   $BWA/$id.dup.sort.bam   -d  -r  $Ref   -o  $Stat/Coverage   ^  $bamDeal   visualize  StatQC   -i  $BWA/$id.dup.sort.bam  -k   -o  $Stat/   ^   $fqcheck  -InFq1   $FqFilter/$sample\_clean_1.fq.gz    -InFq2     $FqFilter/$sample\_clean_2.fq.gz    -OutStat1    $FqFilter/clean_1    -OutStat2    $FqFilter/clean_2    ") ;
	#system ( " $oshbin     01  01   S$sample    zcat   $hash1{$sample}   \\\>  $FqFilter/$sample\_raw_1.fq   ^   zcat    $hash2{$sample}  \\\>    $FqFilter/$sample\_raw_2.fq   ^   $fqcheck  -InFq1    $FqFilter/$sample\_raw_1.fq   -InFq2      $FqFilter/$sample\_raw_2.fq   -OutStat1     $FqFilter/raw_1  -OutStat2 $FqFilter/raw_2 ^   $iTools   Fqtools  filterV2  -InFq1   $FqFilter/$sample\_raw_1.fq   -InFq2    $FqFilter/$sample\_raw_2.fq       -LowQ   7       -OffLowQ        0.3     -OffN   0.1   -OutFq1   $FqFilter/$sample\_clean_1.fq.gz    -OutFq2   $FqFilter/$sample\_clean_2.fq.gz    ^ $fqcheck  -InFq1    $FqFilter/$sample\_clean_1.fq.gz    -InFq2   $FqFilter/$sample\_clean_2.fq.gz  -OutStat1    $FqFilter/clean_1    -OutStat2    $FqFilter/clean_2  ^    $bwa  mem   $Ref    $FqFilter/$sample\_clean_1.fq.gz    $FqFilter/$sample\_clean_2.fq.gz     -R \\\'\@RG\\\\tID:$id\\\\tPL:illumina\\\\tPU:$id\\\\tLB:$id\\\\tSM:$id\\\'-t  4   \\\|   $samtools view  -b      -S      \\\> $BWA/$id.bam  ^     $samtools  fixmate  -m    $BWA/$id.bam  $BWA/$id.srt.bam     ^            $samtoolssort    -m    3999M    $BWA/$id.srt.bam  -O  BAM -o    $BWA/$id.sort.bam   ^   $samtools markdup  $BWA/$id.sort.bam   $BWA/$id.dup.sort.bam ^ rm        $FqFilter/$sample\_raw_1.fq     $FqFilter/$sample\_raw_2.fq  ^  rm    $BWA/$id.srt.bam    $BWA/$id.sort.bam   ^   $samtools  index  $BWA/$id.dup.sort.bam   ") ;
	system ("  qsub  S$sample.sh ") if (defined $ARGV[2]);
	chdir  $outDir ;



}
#close OA ;


