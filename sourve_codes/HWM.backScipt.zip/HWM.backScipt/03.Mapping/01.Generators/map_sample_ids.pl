#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 06月 26日 星期日 11:42:23 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-06-26;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################

open (IA,"$ARGV[0]") || die "input file can't open $!";

#open (OA,">$ARGV[1]") || die "output file can't open $!" ;

################ Do what you want to do #######################

	while(<IA>) 
	{ 
		chomp ; 
		my @inf=split /\//;
		my $id=$inf[-2];
		if ($id<10) {$id="0$id";}
		print "S$id\t$_\n";
		
	}


close IA;
#close OA ;

######################swimming in the sky and flying in the sea ###########################
