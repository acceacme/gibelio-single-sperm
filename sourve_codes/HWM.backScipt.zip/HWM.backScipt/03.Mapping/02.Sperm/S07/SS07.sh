#!/bin/bash
#PBS    -N   SS07.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/00.shell
#Version1.0	jfgui@genomics.org.cn	2022-07-01
ln	-s	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/7/7_R1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/01.Fqfliter/S07_clean_1.fq.gz	
ln	-s	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/7/7_R2.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/01.Fqfliter/S07_clean_2.fq.gz	
/newlustre/home/jfgui/dingmiao/genome/2021-genome/bin/bwa-0.7.17/bwa	mem	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/01.Fqfliter/S07_clean_1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/01.Fqfliter/S07_clean_2.fq.gz	-R	'@RG\\\tID:S07\\\tPL:illumina\\\tPU:S07\\\tLB:S07\\\tSM:S07'	-t	4	|	/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	view	-b	-S	>	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	fixmate	-m	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	sort	-m	8999M	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.srt.bam	-O	BAM	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.sort.bam	
rm	BWA/S07.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	markdup	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.sort.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.dup.sort.bam	
rm	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	index	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.dup.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.dup.sort.bam	-d	-r	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/04.Stat/Coverage	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	visualize	StatQC	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/02.BWA/S07.dup.sort.bam	-k	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S07/04.Stat/	
echo End Time : 
date
