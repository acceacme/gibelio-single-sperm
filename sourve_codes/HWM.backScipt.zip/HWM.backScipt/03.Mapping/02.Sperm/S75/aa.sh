#!/bin/bash
#PBS    -N   aa.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S75/00.shell
#Version1.0	jfgui@genomics.org.cn	2022-08-06
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	BasesCount	-i	../02.BWA/S75.dup.sort.bam	-o	../04.Stat/Site	
perl	../../Staaa.pl	../04.Stat/Site.BaseCount.gz	>	../04.Stat/Hete.win	
echo End Time : 
date
