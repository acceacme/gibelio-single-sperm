#!/bin/bash
#PBS    -N   SS68.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/00.shell
#Version1.0	jfgui@genomics.org.cn	2022-07-01
ln	-s	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/68/68_R1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/01.Fqfliter/S68_clean_1.fq.gz	
ln	-s	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/68/68_R2.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/01.Fqfliter/S68_clean_2.fq.gz	
/newlustre/home/jfgui/dingmiao/genome/2021-genome/bin/bwa-0.7.17/bwa	mem	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/01.Fqfliter/S68_clean_1.fq.gz	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/01.Fqfliter/S68_clean_2.fq.gz	-R	'@RG\\\tID:S68\\\tPL:illumina\\\tPU:S68\\\tLB:S68\\\tSM:S68'	-t	4	|	/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	view	-b	-S	>	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	fixmate	-m	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	sort	-m	8999M	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.srt.bam	-O	BAM	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.sort.bam	
rm	BWA/S68.srt.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	markdup	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.sort.bam	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.dup.sort.bam	
rm	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/samtools-1.15.1/samtools	index	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.dup.sort.bam	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	statistics	Coverage	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.dup.sort.bam	-d	-r	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/01.RefF/Ref.fa	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/04.Stat/Coverage	
/newlustre/home/jfgui/hewm2008/01.Soft/BamDeal-0.25/bin/BamDeal_Linux	visualize	StatQC	-i	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/02.BWA/S68.dup.sort.bam	-k	-o	/newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/02.Mapping/02.S68/04.Stat/	
echo End Time : 
date
