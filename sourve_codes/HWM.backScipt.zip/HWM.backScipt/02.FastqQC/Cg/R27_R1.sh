#!/bin/bash
#PBS    -N   R27_R1.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/09.FqStat/Cg
#Version1.0	jfgui@genomics.org.cn	2022-09-20
/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck	-InFq1	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/27/27_R1.fq.gz	-InFq2	/newlustre/home/jfgui/wy/spermegg/Cg-sperm/27/27_R2.fq.gz	-OutStat1	27_R1.1_fqcheck	-OutStat2	27_R1.2_fqcheck	
echo End Time : 
date
