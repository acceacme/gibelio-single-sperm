#!/usr/bin/perl -w
use strict;
#explanation:this program is edited to 
#edit by jfgui;   2022年 09月 20日 星期二 16:28:41 CST
#Version 1.0    jfgui@genomics.org.cn 

die  "Version 1.0\t2022-09-20;\nUsage: $0 <InPut><Out>\n" unless (@ARGV ==1);

#############Befor  Start  , open the files ####################
    my $list= shift ;
    my $outDir =`pwd` ;  chomp  $outDir ;
    my $oshbin="perl  /newlustre/home/jfgui/hewm2008/01.Soft/command/osh.pl  " ;
    my $run_bin="/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck ";

    open (FL , "<$list") || die "$!" ;
    while (<FL>)
    {
        chomp ;
        my @inf=split/\//;
        my $id=(split(/\./,$inf[-1]))[0];
		$id=~s/_clean_1//g;
		my $ff=<FL>; chomp $ff;
        system ("$oshbin   01 01 R$id  $run_bin   -InFq1  $_    -InFq2   $ff  -OutStat1   $id\.1_fqcheck      -OutStat2   $id\.2_fqcheck" );

    }
    close FL ;
