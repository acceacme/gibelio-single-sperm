#!/bin/bash
#PBS    -N   RCa09.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/09.FqStat/Ca2306V2
#Version1.0	jfgui@genomics.org.cn	2023-06-25
/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck	-InFq1	/newlustre/home/jfgui/hewm2008/03.Project/12.CaReRun/02.Mapping/02.Ca09/01.Fqfliter/Ca09_clean_1.fq.gz	-InFq2	/newlustre/home/jfgui/hewm2008/03.Project/12.CaReRun/02.Mapping/02.Ca09/01.Fqfliter/Ca09_clean_2.fq.gz	-OutStat1	Ca09.1_fqcheck	-OutStat2	Ca09.2_fqcheck	
echo End Time : 
date
