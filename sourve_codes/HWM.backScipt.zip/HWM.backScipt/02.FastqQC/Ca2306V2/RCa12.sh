#!/bin/bash
#PBS    -N   RCa12.sh
#PBS    -l      nodes=1:ppn=4 
#PBS    -q      fat
#PBS    -V
#PBS    -S      /bin/bash
echo Start Time : 
date
cd  /newlustre/home/jfgui/hewm2008/03.Project/11.DanS562RefF/09.FqStat/Ca2306V2
#Version1.0	jfgui@genomics.org.cn	2023-06-25
/newlustre/home/jfgui/hewm2008/01.Soft/fqcheck-2.07/bin/fqcheck	-InFq1	/newlustre/home/jfgui/hewm2008/03.Project/12.CaReRun/02.Mapping/02.Ca12/01.Fqfliter/Ca12_clean_1.fq.gz	-InFq2	/newlustre/home/jfgui/hewm2008/03.Project/12.CaReRun/02.Mapping/02.Ca12/01.Fqfliter/Ca12_clean_2.fq.gz	-OutStat1	Ca12.1_fqcheck	-OutStat2	Ca12.2_fqcheck	
echo End Time : 
date
